﻿using System;

namespace ControlShop.Domain.Contratos.Entities
{
    public interface IPessoaJuridica
    {
        int id { get; set; }
        string nome { get; set; }
        string cnpj { get; set; }
        DateTime dataCadastro { get; set; }
    }
}

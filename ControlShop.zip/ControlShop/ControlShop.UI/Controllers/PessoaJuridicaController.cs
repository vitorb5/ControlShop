﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ControlShop.Domain.Contratos.Services;
using ControlShop.Domain.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ControlShop.UI.Controllers
{
    public class PessoaJuridicaController : Controller
    {

        private readonly IPessoaJuridicaServices pessoaJuridicaServices;

        public PessoaJuridicaController(IPessoaJuridicaServices p)
        {
            this.pessoaJuridicaServices = p ?? throw new ArgumentNullException(nameof(pessoaJuridicaServices));
        }

        // GET: PessoaJuridica
        public async Task<ActionResult> Index()
        {
    
            return View(await pessoaJuridicaServices.BuscarTodosAsync());
        }

        // GET: PessoaJuridica/Details/5
        public async Task<ActionResult> Details(int id)
        {
            return View(await pessoaJuridicaServices.BuscarPorIDAsync(id));
        }

        // GET: PessoaJuridica/Create
        public ActionResult Create()
        {
            return View(new PessoaJuridica());
        }

        // POST: PessoaJuridica/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PessoaJuridica pessoa)
        {
            try
            {
                pessoa.dataCadastro = DateTime.Now;

                if (ModelState.IsValid)
                {
                    pessoaJuridicaServices.CadastrarAsync(pessoa);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Não foi possível cadastrar. Tente novamente....");
            }
            return View(pessoa);
        }

        // GET: PessoaJuridica/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            return View(await pessoaJuridicaServices.BuscarPorIDAsync(id));
        }

        // POST: PessoaJuridica/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, PessoaJuridica pessoa)
        {
            try
            {
                //pessoa.dataCadastro = DateTime.Now;
                if (ModelState.IsValid)
                {
                    PessoaJuridica p = await pessoaJuridicaServices.BuscarPorIDAsync(id);
                    p.nome = pessoa.nome;
                    p.cnpj = pessoa.cnpj;
                    await pessoaJuridicaServices.AtualizarAsync(p);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Não foi possível atualizar. Tente novamente....");
            }
            return View(pessoa);
        }

        // GET: PessoaJuridica/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            PessoaJuridica pessoa = await pessoaJuridicaServices.BuscarPorIDAsync(id);
            return View(pessoa);
        }

        // POST: PessoaJuridica/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, PessoaJuridica pessoa)
        {
            try
            {
                pessoa = await pessoaJuridicaServices.BuscarPorIDAsync(id);
                await pessoaJuridicaServices.DeletarAsync(pessoa);
                
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Não foi possível deletar. Tente novamente....");
            }
            return RedirectToAction("Index");
        }
    }
}
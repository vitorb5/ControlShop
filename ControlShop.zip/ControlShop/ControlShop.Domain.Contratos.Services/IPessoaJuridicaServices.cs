﻿using ControlShop.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ControlShop.Domain.Contratos.Services
{
    public interface IPessoaJuridicaServices
    {
        Task CadastrarAsync(PessoaJuridica PessoaJuridica);

        Task AtualizarAsync(PessoaJuridica PessoaJuridica);

        Task DeletarAsync(PessoaJuridica PessoaJuridica);

        Task<PessoaJuridica> BuscarPorIDAsync(int id);

        Task<IEnumerable<PessoaJuridica>> BuscarTodosAsync();

    }
}

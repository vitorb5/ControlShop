﻿using ControlShop.Domain.Contratos.Entities;
using ControlShop.Domain.Contratos.Repository;
using ControlShop.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace ControlShop.Infra.Data
{
    public class PessoaJuridicaRepository : Repository<PessoaJuridica>, IPessoaJuridicaRepository
    {
        public PessoaJuridicaRepository(DbContext Db) : base(Db)
        {
        }
    }
}

﻿using ControlShop.Domain.Contratos.Entities;
using ControlShop.Domain.Contratos.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace ControlShop.Infra.Data
{
    public class UnitOfWork<T> : IUnitOfWork<T>, IDisposable where T : class
    {

        private IRepository<T> repository;

        public IRepository<T> Repository
        {
            get
            {
                if (this.repository == null)
                {
                    this.repository = new Repository<T>(new Contexto());

                }
                return repository;
            }
        }



        private IPessoaJuridicaRepository pessoaJuridicaRepository;

        public IPessoaJuridicaRepository PessoaJuridicaRepository
        {
            get
            {
                if (this.pessoaJuridicaRepository == null)
                {
                    this.pessoaJuridicaRepository = new PessoaJuridicaRepository(new Contexto());

                }
                return pessoaJuridicaRepository;
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}

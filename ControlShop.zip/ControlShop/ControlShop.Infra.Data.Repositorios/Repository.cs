﻿using ControlShop.Domain.Contratos.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControlShop.Infra.Data
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly DbContext db;

        public Repository(DbContext Db)
        {
            db = Db;

        }

        public virtual void Cadastar(T entidade)
        {
            db.Set<T>().Add(entidade);
            db.SaveChanges();
        }

        public virtual async Task CadastrarAsync(T entidade)
        {
            db.Set<T>().Add(entidade);
            await db.SaveChangesAsync();
        }

        public virtual void Deletar(T entidade)
        {
            db.Set<T>().Remove(entidade);
            db.SaveChanges();
        }

        public virtual async Task DeletarAsync(T entidade)
        {
            db.Entry<T>(entidade).State = EntityState.Deleted;
            await db.SaveChangesAsync();
        }


        public virtual void Editar(T entidade)
        {
            db.Entry<T>(entidade).State = EntityState.Modified;
            db.SaveChanges();

        }

        public virtual async Task EditarAsync(T entidade)
        {
            db.Entry<T>(entidade).State = EntityState.Modified;
            await db.SaveChangesAsync();

        }

        public async virtual Task<T> SelecionarPorIDAsync(int id)
        {
            return await db.Set<T>().FindAsync(id);
        }

        public async virtual Task<IEnumerable<T>> SelecionarTodosAsync()
        {
            return await db.Set<T>().ToListAsync();
        }

        public virtual T SelecionarPorID(int id)
        {
            return db.Set<T>().Find(id);
        }

        public virtual IEnumerable<T> SelecionarTodos()
        {
            return db.Set<T>().ToList();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}

﻿using ControlShop.Domain.Contratos.Entities;
using ControlShop.Domain.Contratos.Repository;
using ControlShop.Domain.Contratos.Services;
using ControlShop.Domain.Entities;
using ControlShop.Infra.Data;
using ControlShop.Services;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace ControlShop.IoC
{
    public class ControlShopIoC
    {
        public IServiceCollection service { get; private set; }

        public ControlShopIoC(IServiceCollection s) => service = s;
        public IServiceCollection DependencyInjection()
        {
           return service.AddSingleton(typeof(IUnitOfWork<>), typeof(UnitOfWork<>))
                .AddScoped(typeof(IPessoaJuridicaServices), typeof(PessoaJuridicaServices))
                .AddTransient(typeof(IPessoaJuridicaRepository), typeof(PessoaJuridicaRepository))
                .AddTransient(typeof(IPessoaJuridica), typeof(PessoaJuridica));
        }
    }
}

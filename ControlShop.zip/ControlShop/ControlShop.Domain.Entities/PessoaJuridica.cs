﻿using ControlShop.Domain.Contratos.Entities;
using System;

namespace ControlShop.Domain.Entities
{
    public class PessoaJuridica : IPessoaJuridica
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string cnpj { get; set; }
        public DateTime dataCadastro { get; set; }
    }
}

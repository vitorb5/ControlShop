﻿using ControlShop.Domain.Contratos.Repository;
using ControlShop.Domain.Contratos.Services;
using ControlShop.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ControlShop.Services
{
    public class PessoaJuridicaServices : IPessoaJuridicaServices
    {
        private readonly IUnitOfWork<PessoaJuridica> unitOfWork;

        public PessoaJuridicaServices(IUnitOfWork<PessoaJuridica> unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public async Task AtualizarAsync(PessoaJuridica PessoaJuridica)
        {
            await unitOfWork.Repository.EditarAsync(PessoaJuridica);
        }

        public async Task<PessoaJuridica> BuscarPorIDAsync(int id)
        {
            return await unitOfWork.Repository.SelecionarPorIDAsync(id);
        }

        public async Task<IEnumerable<PessoaJuridica>> BuscarTodosAsync()
        {
            return await unitOfWork.Repository.SelecionarTodosAsync();
        }

        public async Task CadastrarAsync(PessoaJuridica PessoaJuridica)
        {
            await unitOfWork.Repository.CadastrarAsync(PessoaJuridica);
        }

        public async Task DeletarAsync(PessoaJuridica PessoaJuridica)
        {
            await unitOfWork.Repository.DeletarAsync(PessoaJuridica);
        }
    }
}

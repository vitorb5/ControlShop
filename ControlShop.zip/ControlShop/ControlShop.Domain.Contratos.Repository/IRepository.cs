﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ControlShop.Domain.Contratos.Repository
{
    public interface IRepository<T> : IDisposable
    {
        void Cadastar(T entidade);
        Task CadastrarAsync(T entidade);
        void Editar(T entidade);
        Task EditarAsync(T entidade);
        void Deletar(T entidade);
        Task DeletarAsync(T entidade);
        Task<IEnumerable<T>> SelecionarTodosAsync();
        IEnumerable<T> SelecionarTodos();
        Task<T> SelecionarPorIDAsync(int id);
        T SelecionarPorID(int id);
    }
}

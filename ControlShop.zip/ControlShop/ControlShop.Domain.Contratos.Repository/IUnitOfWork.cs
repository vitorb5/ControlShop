﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ControlShop.Domain.Contratos.Repository
{
    public interface IUnitOfWork<T>
    {
        IRepository<T> Repository { get; }

        IPessoaJuridicaRepository PessoaJuridicaRepository { get; }
    }
}

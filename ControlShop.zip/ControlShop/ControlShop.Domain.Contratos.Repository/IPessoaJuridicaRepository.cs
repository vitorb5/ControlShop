﻿using ControlShop.Domain.Contratos.Entities;
using ControlShop.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ControlShop.Domain.Contratos.Repository
{
    public interface IPessoaJuridicaRepository : IRepository<PessoaJuridica>
    {
    }
}
